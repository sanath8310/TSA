from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
import pandas as pd
import re 
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB 
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import classification_report
from sklearn import metrics
from sklearn.externals import joblib 
from yellowbrick.classifier import ClassificationReport
import tweepy
from nltk.stem import PorterStemmer
from nltk.tokenize import RegexpTokenizer
import nltk
from nltk.corpus import stopwords
stopwords = set(stopwords.words('english'))

# Create your views here.

def home(request):
    return render(request, 'home.html')

def train(request):
    dataset=pd.read_csv('C:/Users/Sanathkumar MP/miniproject/TSA/static/app1/resource/trained_data.csv')
    data = pd.read_csv('C:/Users/Sanathkumar MP/miniproject/TSA/static/app1/resource/dataset.csv')
    data = data.to_html
    pdata = dataset[['preprocess_txt','sentiment']]     

    return render(request, 'result.html',{'data':data,'pdata':pdata.to_html})

def test(request):
    return render(request, 'test.html')

def test1(request):
    text = request.POST['t1']
    if text=='':
        return render(request, 'test1.html',{'res1':'Enter tweet!'})
    tv = TfidfVectorizer(binary=False, ngram_range=(1,3))
    dataset=pd.read_csv('C:/Users/Sanathkumar MP/miniproject/TSA/static/app1/resource/trained_data.csv')
    dataset_X = tv.fit_transform(dataset['preprocess_txt'])
    dataset_Y = dataset.iloc[:, 2].values 

    X_train, X_test, y_train, y_test = train_test_split( dataset_X, dataset_Y, test_size = 0.2, random_state = 20) 
    classifier = MultinomialNB(); 
    classifier.fit(X_train, y_train) 
    msg=[text]
    test=tv.transform(msg)
    pred=classifier.predict(test)

    def res(pred):
        if(pred==0):
            return 'Negetive tweet'
        elif(pred==2):
            return 'Neutral tweet'
        elif(pred==4):
            return 'Positive tweet'
        else:
            return 'There is some error!'
    result = res(pred)

    return render(request, 'test1.html',{'res':result})

def test2(request):
    nltk.download('punkt')
    nltk.download('averaged_perceptron_tagger')
    nltk.download('wordnet')
    name = request.POST['t2']
    if name=='':
        return render(request, 'test2.html',{'res1':'Enter user name!'})
    # Twitter Api Credentials
    ACCESS_TOKEN = "939727461448740864-nq7R2Lcg0aamzYXlEhUkK5xo1Fv37pe"
    ACCESS_TOKEN_SECRET = "Mro8rZKRPsZks3vIAzuDj9h7vJCk7PkOmVSwWdpzvnsVh"
    CONSUMER_KEY = "CIDAhfuWvjYpWBv57mR51eD8f"
    CONSUMER_SECRET = "I1zb6XEVY8fohqXp0pQaONW4vUTlXmdI0vYWGGyqksN6HDSEK7"

    authenticate = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
    authenticate.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET) 
    api = tweepy.API(authenticate, wait_on_rate_limit = True)
    posts = api.user_timeline(screen_name=name, count = 200, lang ="en", tweet_mode="extended")
    if posts=='':
        return render(request, 'test2.html',{'res1':'Enter valid user name!'})

    df = pd.DataFrame([tweet.full_text for tweet in posts], columns=['Tweets'])
    def cleanTxt(text):
        text = re.sub('@[A-Za-z0–9]+', '', text) #Removing @mentions
        text = re.sub('#', '', text) # Removing '#' hash tag
        text = re.sub('RT[\s]+', '', text) # Removing RT
        text = re.sub('https?:\/\/\S+', '', text) # Removing hyperlink
        return text
    
    def sup_repeat(text):
        rpt_regex = re.compile(r"(.)\1{1,}", re.IGNORECASE);
        def rpt_repl(match):
            return match.group(1)+match.group(1)
        text = re.sub( rpt_regex, rpt_repl, text )
        return text
    def getTokens(tweets):
        tweets=tweets.lower()
        tokenizer = RegexpTokenizer("[\w']+")
        tweets_token=tokenizer.tokenize(tweets) 
        tokens_without_sw = [word for word in tweets_token if not word in stopwords]
        text = ' '.join(tokens_without_sw)
        return text

    ps=PorterStemmer()
    df['clean_txt'] = df['Tweets'].apply(cleanTxt)
    df['clean_txt'] = df['clean_txt'].str.replace("[^a-zA-Z#]", " ")
    df['clean_txt'] = df['clean_txt'].apply(lambda x: ' '.join([w for w in x.split() if len(w)>3]))
    df['tokenized_txt']=df['clean_txt'].apply(getTokens) 
    df['preprocess_txt']= df['tokenized_txt'].apply(lambda x: ' '.join([ps.stem(word) for word in x.split()]))
    df['preprocess_txt']=df['preprocess_txt'].apply(sup_repeat)
    
    tv = TfidfVectorizer(binary=False, ngram_range=(1,3))
    dataset=pd.read_csv('C:/Users/Sanathkumar MP/miniproject/TSA/static/app1/resource/trained_data.csv')
    dataset_X = tv.fit_transform(dataset['preprocess_txt'])
    dataset_Y = dataset.iloc[:, 2].values 

    X_train, X_test, y_train, y_test = train_test_split( dataset_X, dataset_Y, test_size = 0.2, random_state = 20) 
    classifier = MultinomialNB(); 
    classifier.fit(X_train, y_train) 

    X = tv.transform(df['preprocess_txt'])
    label=classifier.predict(X)
    df['sentiment']=label
    dataframe  = df[['Tweets','preprocess_txt','sentiment']]
    data1 = dataframe[dataframe['sentiment']==4]
    data2 = dataframe[dataframe['sentiment']==0]
    data3 = dataframe[dataframe['sentiment']==2]
    data1 = data1[['Tweets']]
    data2 = data2[['Tweets']]
    data3 = data3[['Tweets']]
    return render(request, 'test2.html',{'data1':data1.to_html,'data2':data2.to_html,'data3':data3.to_html})

def python_code(request):
    return render(request, 'python_code.html')
