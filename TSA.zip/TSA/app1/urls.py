from django.urls import path
from . import views

urlpatterns = [

    path('',views.home, name='home'),
    path('train_model',views.train,name='train'),
    path('test_model',views.test,name='test'),
    path('test1',views.test1,name='test1'),
    path('test2',views.test2,name='test2'),
    path('python_code',views.python_code,name='python_code')
]